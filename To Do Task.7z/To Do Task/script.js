const inputText = document.getElementById('inputtext');
const taskList = document.getElementById('list');

// Add task when "Add" button is clicked or "Enter" key is pressed
inputText.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        addTask();
    }
});

function addTask() {
    const taskText = inputText.value.trim();

    if (taskText === '') return;

    const li = document.createElement('li');
    li.innerHTML = `
        ${taskText}
        <div>
            <button class="complete-btn">Complete</button>
            <button class="delete-btn">Delete</button>
        </div>
    `;

    taskList.appendChild(li);
    inputText.value = '';

    // Add complete and delete functionality
    li.querySelector('.delete-btn').addEventListener('click', function() {
        li.remove();
    });

    li.querySelector('.complete-btn').addEventListener('click', function() {
        li.classList.toggle('completed');
    });
}
